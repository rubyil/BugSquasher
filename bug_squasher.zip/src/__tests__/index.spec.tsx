import React from 'react'

import App from '../App'

describe("<App />", () => {
  test('should display Hello World', async () => {
  })
})
