declare module "*.png";
