import React from 'react'
import World from './World'
import './styles.css'

function App() {
  return (
    <World />
  )
}

export default App
